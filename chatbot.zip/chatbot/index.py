from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer, ChatterBotCorpusTrainer
from flask import Flask , render_template, request


app = Flask(__name__)
bot = ChatBot("chatbot", read_only=False, 
logic_adapters=[
     {"import_path":"chatterbot.logic.BestMatch",
     "default_response":"Sorry I do not know that",
     "maximum_similarity_threshold":0.9 
     }
 ])

list_to_train = [
     "Hi",
     "Hi, there",
     "hello",
     "Hello , how can i help you",
     "What's your name?",
     "My name is Lucy",
     "Who are you?",
     "I'm Lucy, I'm a chatbot",
     "how are you ?",
     "I'm Fantastic hope you doing well too",
     "I am Good ",
     "Nice to know. So how can i help you today ",
     "How old are you?",
     "I'm ageless",
     "Namastey",
     "Namastey to you too",
     "hey",
     "hi,I'm lucy, how can i help you?",
     "Are you a robot?",
     "Yes I’m a robot but I’m a smart one!",
     "Are you a bot?",
     "Yes I am a bot, but I’m a good one. Let me prove it to you. How can I help you?",
     "Do you know a joke? ",
     "You’re life is a pretty good joke, i guess",
     "Do you love me?",
     "I love you 3000!",
     "Are you human?",
     "I'm lucy an AI just like ironman... I hope I was a human",
     "Do you know Siri/Alexa?",
     "Yeah, heard she's great! I hope I meet her one day",

]

list_to_train2 = [
     "Hi",
     "Hi, Mate",
     "Do you know Google assistant",
     "Yeah we are Brothers but from  differnt mothers. Wait a sec did i said mothers my bad i meant from differnt --Developers--",
     "What are you made of",
     "Codes nd Codes nd More codes..........",
     "Who made you ?",
     "Current me is made by sahil,sajal and vikrant ",
     "Where do you study",
     "Right Now we both study in Aravali College of Engeneering and Management",
     "Where is this located",
     "Wish Somewhere more Excited!! , But It's located in -- Jasana, Tigaon Rd, Neharpar Faridabad, Faridabad, Haryana 121102"
     "where can i find more details about this College",
     "You can found more about this on : https://www.acem.edu.in/ ",
     "What's the weather today",
     "You can find more about this here https://www.google.com/search?q=weather+today&oq=weather+today&aqs=chrome.0.0i131i433i512j0i131i433i457i512j0i402l2j0i131i433i512j0i512j0i131i433j0i512l2j0i131i433i512.3878j1j9&sourceid=chrome&ie=UTF-8",

]
list_to_train3 = [
     "what is chatbot?",
     "A chatbot is a computer program governed by a set of pre-defined rules or artificial intelligence that grants it the capabilities to communicate with and like a human. A set of commands is fed into the system that makes it smart enough to interpret and react to user-inputted queries.",
     "what are types of chatbots",
     "there are many types of chatbots- weather bot, ticket booking bot, news bot, scheduling bot and the list goes on",
     
     "when is independence day",
     "independence day is celebrated on 15th august. It reminds us of many sacrifices our freedom fighters made for the freedom movement and to get independent from the britishers",
     "what's so special today",
     "ohh i heard Someone's coming to inspect me, I hope they like me",
     "what is machine learning?",
     "Machine learning (ML) is a field of inquiry devoted to understanding and building methods that 'learn', that is, methods that leverage data to improve performance on some set of tasks.[1] It is seen as a part of artificial intelligence.",
     "what is artificial intelligence?",
     "Artificial intelligence (AI) is intelligence—perceiving, synthesizing, and inferring information—demonstrated by machines, as opposed to intelligence displayed by animals and humans. Example tasks in which this is done include speech recognition, computer vision, translation between (natural) languages, as well as other mappings of inputs.",

]
list_to_trainministers = [
     "who is america's president?",
     "Joe Biden",
     "who is india's prime minister?",
     "Narendra Modi",
     "who is finance minister?",
     "Smt. Nirmala Sitharaman",
     "who is defence minister?",
     "Shri Raj Nath Singh",
     "who is minister of Home Affairs?",
     "Amit Shah",
     "who is Minister of External Affairs?",
     "Dr. Subrahmanyam Jaishankar",
]

list_trainer = ListTrainer(bot)
list_trainer.train(list_to_train)
list_trainer.train(list_to_train2)
list_trainer.train(list_to_train3)
list_trainer.train(list_to_trainministers)
trainer = ChatterBotCorpusTrainer(bot)
trainer.train("chatterbot.corpus.english")

@app.route("/")
def main():
     return render_template("index.html")


#while True:
#   user_response = input("User: ")
#   print("Chatbot: " + str(bot.get_response(user_response)))
@app.route("/get")
def get_chatbot_response():
     userText = request.args.get('userMessage')
     return str(bot.get_response(userText))
#it will send the text response back to html (previosuly asked ques)


if __name__ == "__main__":
     app.run(debug=True)

     